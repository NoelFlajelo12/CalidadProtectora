package protectora;

public class SexoException extends Exception {
	
	public SexoException() {
		
	}
}
