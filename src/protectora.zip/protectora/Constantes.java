package protectora;

public interface Constantes {
	
	public final static int  MAX_SOLICITUDES=10;
	static int MAX_ANIMALES=100;
	static int PRECIO_LEHISMANIA=25;
	static int VACUNA=30;
	static int SEDANTE=8;
	static int NO_ESTERILIZADA=10;
	static int CANTIDAD_FIJA=1000;
	static double MAX_EDAD=1.5;
	static int MAX_PESO_PERRO_P=15;
	static double COMIDA_PERRO_P=0.2;
	static int  MAX_PESO_PERRO_M=25;
	static double COMIDA_PERRO_M=0.3;
	static double P_COMIDA_PERRO_G = 0.15;
}