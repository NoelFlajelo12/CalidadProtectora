package protectora;

public class Gato extends Animal {      // Piense si habría que incluir algún método por el coste o gasto???

	private boolean esterilizado;
	
	public Gato (String nombre,TSexo sexo, int edad, boolean sociable, boolean apadrinado, boolean esterilizado ) {
	
		super(nombre,sexo,edad,sociable,apadrinado);
		this.esterilizado = esterilizado;
		//this.solicitudes=solicitudes;
		//this.n_Solicitudes=n_Solicitudes;
	}
	
	public boolean isEsterilizado() {
		return esterilizado;
	}

	public void setEsterilizado(boolean esterilizado) {
		this.esterilizado = esterilizado;
	}
	
	public String toString() {
		return "[GATO: "+super.toString()+ " esterilizado: " +esterilizado+"] ";
	}
	
}
