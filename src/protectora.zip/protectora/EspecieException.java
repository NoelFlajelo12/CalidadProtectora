package protectora;

public class EspecieException extends Exception {
	
public EspecieException() {
		
	}

}
