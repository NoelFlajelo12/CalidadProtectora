package protectora;

public class AnimalNoExistente extends Exception {

	public AnimalNoExistente() {
		
	}
}
