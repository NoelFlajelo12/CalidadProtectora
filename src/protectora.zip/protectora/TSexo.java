package protectora;

public enum TSexo {
MACHO,HEMBRA
}
