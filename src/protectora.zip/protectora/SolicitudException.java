package protectora;

public class SolicitudException extends Exception{

	public SolicitudException() {
		
	}
}
