package protectora;

import java.io.*;
import java.util.*;
                                                             
public class Principal {

	final static Scanner teclado = new Scanner(System.in);
	
	public static void main(String[] args) {
		int opcion = 0;
		Protectora protect=new Protectora("hola",1000);
		leerFichero leer=new leerFichero();
		leer.leerAnimales(".\\Animales.txt",protect);
		leer.leerSolicitudes(".\\Solicitudes.txt", protect);
		Animal [] animales = null;
		String nombre;
		
		
		do {
			//No sabemos por qué, pero el case 8 nos da error
			System.out.println("Elija una opcion: \n1. Mostrar animales\n2. Realizar solicitud de adopcion o acogida\n3. Consultar listado de solicitudes de un Animal\n4. Calcular coste de los gastos veterinarios" +
					"\n5. Calcular coste Esterilización\n6. Calcular cantidad de pienso de perro adulto\n7. Calcular subvencion\n8. Añadir nuevo animal\n9. Buscar un animal\n10. Cerrar el programa.");
			opcion = teclado.nextInt();
		
			switch(opcion) {
		
				case 1: 
					animales = protect.getAnimales();
					for(int i=0;i<protect.getContador();i++) {
						System.out.println(animales[i].toString());
					}
					break;
				case 2:
					System.out.println("");
					System.out.println("Elija el animal al que añadir una solicitud");
					nombre = teclado.next();
					try {
						Solicitud nuevaSolicitud= nuevaSolicitud(nombre);
						protect.getAnimal(nombre).addSolicitud(nuevaSolicitud);
						System.out.println("La solicitud se ha completado con exito");
					}catch(NullPointerException e) {
						System.out.println("El animal no existe");
					}
					
					break;
				case 3: 
					
					System.out.println("Introduzca el nombre del animal del que se quiere obtener los datos sobre solicitudes de adopcion");
					nombre = teclado.next();
					if(protect.getAnimal(nombre) == null) {
						System.out.println("No existe un animal con ese identificador");
					}else {
						System.out.println(protect.getAnimal(nombre).mostrarSolicitudesAdopcion());
					}
					break;
				case 4: 
					System.out.println(protect.getCostesVeterinarios());
					break;
				case 5: 
					Clinica_Veterinaria veterinaria = nuevaVeterinaria();
					double costeEsterilizacion = protect.getNumeroGatasNoEsterilizadas() * veterinaria.getPrecioEsterilizacion();
					System.out.println("El coste de la esterilizacion de todas las gatas no esterilizadas seria de : " +costeEsterilizacion+" Euros");
					break;
				case 6:
					System.out.printf("%nLa cantidad de pienso estimada para una semana es: %.2f Kg %n", protect.cantidadPienso());
					break;
				case 7:
					Ayuntamiento ayuntamiento = nuevoAyuntamiento();
					double subvencion = ayuntamiento.calcularSubvencion(protect);
					System.out.println("La subvencion que concede el ayuntamiento por los animales que hay en la protectora es de: "+ subvencion+"�");
					break;
				case 8:
					System.out.println("Introduzca los datos del animal");
						Animal nAnimal = nuevoAnimal(protect);
						protect.anadirAnimal(nAnimal);
						//Nos da un error en este apartado, hemos debugueaod y no sabemos por que nos da
					break;
				case 9:
					System.out.println("Introduzca el nombre del animal del que se quiere obtener los datos");
					nombre = teclado.next();
					
					if(protect.getAnimal(nombre) == null) {
						System.out.println("No existe un animal con ese identificador");
					}else {
						System.out.println(protect.getAnimal(nombre).toString());
					}
					break;
				case 10:
					break;
				default: System.out.println("Opcion incorrecta");
			}
		}while(opcion != 10);
		
		System.out.println("Fin");
		
		
		
		
	}
	public static Solicitud nuevaSolicitud(String nombre) {
		TSolicitud tipoSolicitud = null;
		System.out.println("Que clase de solicitud quiere hacer:");
		String tSolicitud = teclado.next();
		if(tSolicitud.equalsIgnoreCase("Adopcion")) {
			tipoSolicitud = TSolicitud.ADOPCION;
		}if(tSolicitud.equalsIgnoreCase("Acogida")) {
			tipoSolicitud = TSolicitud.ACOGIDA;
		}	
		
		System.out.println("Introduzca el numero de contacto");
		long telContacto = teclado.nextLong();
		Solicitud solicitudNueva = new Solicitud(tipoSolicitud,telContacto);
		return solicitudNueva;
	}
	public static Animal nuevoAnimal(Protectora protect) {
		escribirFichero wFichero =new escribirFichero();
		String lineaAnimal;
		Animal animal = null;
		char caracterEspecie = ' ';
		int edad = 0;
		TSexo sexo= null;
		boolean sociable= false,apadrinado=false, peligroso = false,leishmania = false,esterilizado= false;
		
		while(caracterEspecie == ' ') {
			System.out.println("Quiere introducir los datos de un Perro o un Gato [Perro/Gato]");
			String especie =teclado.next();
			if(especie.equalsIgnoreCase("Perro")) {
				caracterEspecie = 'p';
			}
			else if(especie.equalsIgnoreCase("Gato")) {
				caracterEspecie = 'g';
			}else {
				System.out.println("error al introducir el tipo de animal");
			}
		}
		System.out.println("Introduzca el nombre del animal");
		String nNuevoAnimal = teclado.next();
		if(protect.getAnimal(nNuevoAnimal) == null) {
			
			String sexoLinea= "";
			while(sexo == null) {
				System.out.println("Introduzca el sexo: [m/h] ");
				sexoLinea = teclado.next();
				try {
					if(sexoLinea.equalsIgnoreCase("m")) {
						sexo=TSexo.MACHO;
						throw new SexoException();
					}
					if (sexoLinea.equalsIgnoreCase("h")) {
						sexo=TSexo.HEMBRA;
						throw new SexoException();
					}
				}catch(SexoException SE) {
				
				}
			}
			//Edad del animal
			System.out.println("Introduzca la edad del animal");
			edad = teclado.nextInt();
			//Si es sociable o no
			System.out.println("Introduzca si es sociable el animal [Si/No]");
			sociable = incognitaTeclado(sociable);
			//si es apadrinado o no
			System.out.println("Introduzca si esta apadrinado el animal [Si/No]");
			apadrinado = incognitaTeclado(apadrinado);
			
			
			switch (caracterEspecie){
			
			case 'p':
				System.out.println("Introduzca la raza del perro");
				String raza = teclado.next();
				System.out.println("Introduzca el peso del perro");
				int peso = teclado.nextInt();
				System.out.println("Introduzca si es peligroso el perro [Si/No]");
				peligroso = incognitaTeclado(peligroso);
				System.out.println("Introduzca si tiene leishmania el perro [Si/No]");
				leishmania = incognitaTeclado(leishmania);
				
				animal = new Perro(nNuevoAnimal,sexo,edad,sociable,apadrinado,raza,peso,peligroso,leishmania);
				//Creamos un perro, o un gato en principio pero no nos dejaba usar break
				lineaAnimal = caracterEspecie + " "+ nNuevoAnimal + " "+ sexoLinea +" "+ edad + " "+ sociable +" "+ apadrinado +" " +raza+" "+peso+" "+peligroso+" "+ leishmania;
				wFichero.escribirAnimal(".\\Animales.txt", lineaAnimal);
				return animal;
				//break;
			case 'g':
				System.out.println("Introduzca si esta esterilizado el gato [Si/No]");
				esterilizado = incognitaTeclado(esterilizado);
				
				animal = new Gato(nNuevoAnimal,sexo,edad,sociable,apadrinado,esterilizado);
				lineaAnimal = caracterEspecie + " "+ nNuevoAnimal + " "+ sexoLinea +" "+ edad + " "+ sociable +" "+ apadrinado +" " +esterilizado;
				wFichero.escribirAnimal(".\\Animales.txt", lineaAnimal);
				return animal;
				//break;
			default:
				System.out.println("Opcion incorrecta");
				return animal=null;
				//break;
			
			
		}
		} else {
			System.out.println("Ya existe un animal con este identificador");
			return animal = null;
		}
		//return animal;
		
	}
	public static Clinica_Veterinaria nuevaVeterinaria() {
		System.out.println("Introduzca el nombre de la clinica");
		String nombreClinica = teclado.next();
		
		long telVeterinaria = 0;
		double precioEsterilizacion;
		//while((telVeterinaria >= 900000000 && telVeterinaria <= 999999999) || (telVeterinaria >= 600000000 && telVeterinaria <= 699999999)) {
		System.out.println("Introduzca el telefono de contacto de "+nombreClinica+ ":");
		 telVeterinaria = teclado.nextLong();
		//}
		System.out.println("Introduzca el precio de la operacion de esterilizacion.");
		precioEsterilizacion = teclado.nextDouble();
		
		Clinica_Veterinaria veterinaria = new Clinica_Veterinaria(nombreClinica,telVeterinaria,precioEsterilizacion);
		
		return veterinaria;
	}
	public static Ayuntamiento nuevoAyuntamiento() {
		
		
		long telContacto=0;
		double cantidad_variable;
		//while((telContacto >= 900000000 && telContacto <= 999999999) || (telContacto >= 600000000 && telContacto <= 699999999)) {
		System.out.println("Introduzca el telefono de contacto del ayuntamieto");
		telContacto = teclado.nextLong();
		//}
		System.out.println("Introduzca cantidad de subvenci�n que concede por animal recogido.");
		cantidad_variable = teclado.nextDouble();
		
		Ayuntamiento ayuntamiento = new Ayuntamiento(telContacto,cantidad_variable);
		
		return ayuntamiento;
	}
	
	public static boolean incognitaTeclado(boolean incognita) {
		boolean opcionIncognita = false;
		
		while(!opcionIncognita) {
			String incognitaLinea = teclado.next();
			if(incognitaLinea.equalsIgnoreCase("Si")) {
				incognita = true;
				opcionIncognita = true;
			}
			else if(incognitaLinea.equalsIgnoreCase("No")) {
				opcionIncognita = true;
			}else {
				System.out.println("Error, vuelva a introducir [Si/No]");
			}
		}
		return incognita;
	}
	

	
	
}
