package protectora;

public enum TSolicitud {
ACOGIDA,ADOPCION
}
