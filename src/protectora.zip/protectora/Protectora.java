package protectora;

                    /// Falta método añadir animal,, también buscar animal...

public class Protectora implements Constantes{
	private String nombreProtectora;
	private Animal [] animal=new Animal [MAX_ANIMALES];
	private double presupuesto;
	private int numAnimales=0;
	//private Ayuntamiento ayuntamiento=new Ayuntamiento(0,1000,92635);  // Esto para qué???
	//private Clinica_Veterinaria clinica=new Clinica_Veterinaria("tomalo",92636,50);   /// Esto para qué???
	
	public Protectora(String nombreProtectora,double presupuesto) {
		this.nombreProtectora=nombreProtectora;
		this.presupuesto=presupuesto;
		numAnimales = 0;
		//this.ayuntamiento=ayuntamiento;
		//this.clinica=clinica;
	}
	                                              //// Crear otro Constructor quitando vector de animales, 
												  //// es más natural utilizar un método para añadir animales,,
												  //// Además, Se va a tener que utilizar necesariamente porque 
												  //// no vamos a tener todos los animales al principio, irán llegando "nuevos"
	
	public void anadirAnimal(Animal animal) {
		//Excepcion si no tenemos espacio
		try {
		this.animal[numAnimales]=animal;
		numAnimales++;
		}catch(IndexOutOfBoundsException e) {
			System.out.println("Superada la capicidad de la protectora");
		}
	}
	
	public Animal getAnimal(String nombreAnimal) {
		Animal animal2 = null;
		boolean enc = false;
		
		for(int i=0;(i<numAnimales) && !enc ;i++) {
			String nAnimal = animal[i].getNombre();
			if(nAnimal.equalsIgnoreCase(nombreAnimal)) {
				//System.out.println(animal[i].mostrarAnimal());
				animal2 = animal[i];
				enc = true;
			}
			//Añadir boo
		}
		return animal2;
	}
	
	public Animal[] getAnimales() {
		Animal animal3[] = new Animal[MAX_ANIMALES];
		for(int i=0;i<numAnimales;i++) {
			
			animal3[i]=animal[i];
		}
		return animal3;
	}
	
	public int getNumeroGatasNoEsterilizadas() {
		int contGatas = 0;
		for(int i=0;i<numAnimales;i++) {
			if (animal[i].getSexo() == TSexo.HEMBRA && (animal[i]) instanceof Gato && !((Gato)animal[i]).isEsterilizado()) { //2 if por si acaso , 1 el instace of y el otro
				contGatas++;
			}
		}
		return contGatas;
	}
	public double getCostesVeterinarios() {
		double costes =0;
		for(int i=0;i<numAnimales;i++) {
			if(!animal[i].isApadrinado()) {
				if(animal[i] instanceof Perro) {
					costes +=VACUNA;
					if(((Perro)animal[i]).getPeligroso()) {
						costes +=SEDANTE;
					}
					if(((Perro)animal[i]).getLeishmania()) {
						costes+=(PRECIO_LEHISMANIA*12);
					}
				}
				if(animal[i] instanceof Gato) {
					if(animal[i].getSexo() == TSexo.HEMBRA && !((Gato)animal[i]).isEsterilizado()) {
						costes += (NO_ESTERILIZADA * 12);
					}
				}
			}
			
		}
		return costes;
	}
	
	public double cantidadPienso() {
		double comida = 0;
		for(int i=0;i<numAnimales;i++) {
			if(animal[i] instanceof Perro) {
				if(animal[i].getEdad() > MAX_EDAD) {
					comida+= (((Perro)animal[i]).cantidadComida()*7);
				}
			}
		}
		return comida;
	}

	public String getNombre() {
		return nombreProtectora;
	}
	public void setNombre(String nombreProtectora) {
		this.nombreProtectora = nombreProtectora;
	}
	public Animal[] getAnimal() {     /// en todo caso sería "animales" porque no será un vector "animal"
		return animal;
	}
	public void setAnimal(Animal[] animal) {    // "animales"
		this.animal = animal;
	}
	public double getPresupuesto() {
		return presupuesto;
	}
	public void setPresupuesto(double presupuesto) {
		this.presupuesto = presupuesto;
	}
	public int getContador() {
		return numAnimales;
	}
	
	
}
